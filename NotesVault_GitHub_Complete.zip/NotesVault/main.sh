#!/bin/bash
# Notes Vault - Linux Notes Management System
set -o pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR" || exit 1
NOTES_DIR="$PROJECT_DIR/data/notes"
BACKUP_DIR="$PROJECT_DIR/backups"
LOG_DIR="$PROJECT_DIR/logs"
REPORT_DIR="$PROJECT_DIR/reports"
LOG="$LOG_DIR/activity.log"
source "$PROJECT_DIR/lib/functions.sh"
mkdir -p "$NOTES_DIR" "$BACKUP_DIR" "$LOG_DIR" "$REPORT_DIR"
touch "$LOG"

create_note() {
    local title tags slug filename file line
    echo "----------- CREATE NOTE -----------"
    read -r -p "Enter note title: " title
    [[ -z "${title//[[:space:]]/}" ]] && { echo "Title cannot be empty."; return 1; }
    read -r -p "Enter tags (example: #linux #bash): " tags
    [[ -z "${tags//[[:space:]]/}" ]] && { echo "Tags cannot be empty."; return 1; }
    slug="$(printf '%s' "$title" | tr '[:upper:]' '[:lower:]' | sed -E 's/[^a-z0-9]+/_/g; s/^_+|_+$//g')"
    [[ -z "$slug" ]] && slug="note"
    filename="${slug}_$(date '+%Y%m%d_%H%M%S').txt"
    file="$NOTES_DIR/$filename"
    {
        printf 'Title: %s\nTags: %s\nCreated: %s\n' "$title" "$tags" "$(date '+%Y-%m-%d %H:%M:%S')"
        echo "----------------------------------------"
        echo "Enter note content. Type END on a separate line to finish."
        while IFS= read -r line; do
            [[ "$line" == "END" ]] && break
            printf '%s\n' "$line"
        done
    } > "$file"
    echo "Saved: data/notes/$filename"
    log_activity "Created note: $filename"
}

search_notes() {
    local query
    read -r -p "Enter keyword or tag: " query
    [[ -z "${query//[[:space:]]/}" ]] && { echo "Search cannot be empty."; return 1; }
    echo "Search results:"
    if ! find "$NOTES_DIR" -maxdepth 1 -type f -name '*.txt' -exec grep -ilF -- "$query" {} +; then
        echo "No matching notes found."
    fi
    log_activity "Searched notes for: $query"
}

recent_notes() {
    local file found=0
    echo "----------- FIVE MOST RECENT NOTES -----------"
    while IFS= read -r -d '' file; do
        found=1
        echo
        echo "File: $(basename "$file")"
        echo "Modified: $(date -r "$file" '+%Y-%m-%d %H:%M:%S')"
        sed -n '1,8p' "$file"
    done < <(find "$NOTES_DIR" -maxdepth 1 -type f -name '*.txt' -printf '%T@ %p\0' | sort -z -nr | head -z -n 5 | while IFS= read -r -d '' item; do printf '%s\0' "${item#* }"; done)
    [[ $found -eq 1 ]] || echo "No notes available."
    log_activity "Viewed recent notes"
}

count_tags() {
    echo "----------- NOTE COUNT BY TAG -----------"
    if ! compgen -G "$NOTES_DIR/*.txt" >/dev/null; then echo "No notes available."; return; fi
    grep -h '^Tags:' "$NOTES_DIR"/*.txt 2>/dev/null |
      sed 's/^Tags:[[:space:]]*//' | tr ' ,' '\n\n' |
      grep -E '^#[[:alnum:]_-]+' | sort | uniq -c | sort -nr
    log_activity "Counted notes by tag"
}

view_all_notes() {
    local file found=0
    while IFS= read -r -d '' file; do
        found=1
        echo
        echo "File: $(basename "$file")"
        echo "----------------------------------------"
        cat "$file"
    done < <(find "$NOTES_DIR" -maxdepth 1 -type f -name '*.txt' -print0 | sort -z)
    [[ $found -eq 1 ]] || echo "No notes available."
    log_activity "Viewed all notes"
}

view_activity_log() {
    echo "----------- RECENT ACTIVITY -----------"
    [[ -s "$LOG" ]] && tail -n 20 "$LOG" || echo "Activity log is empty."
}

run_menu() {
    local choice
    while true; do
        clear
        echo "======================================"
        echo "       NOTES VAULT - NOTES MANAGER"
        echo "======================================"
        echo "1. Create a new note"
        echo "2. Search notes"
        echo "3. View 5 most recent notes"
        echo "4. Count notes by tag"
        echo "5. Create compressed backup"
        echo "6. View all notes"
        echo "7. View activity log"
        echo "0. Exit"
        echo "======================================"
        read -r -p "Enter your choice: " choice
        case "$choice" in
          1) create_note ;;
          2) search_notes ;;
          3) recent_notes ;;
          4) count_tags ;;
          5) create_backup ;;
          6) view_all_notes ;;
          7) view_activity_log ;;
          0) log_activity "Exited application"; echo "Thank you for using Notes Vault!"; break ;;
          *) echo "Invalid choice." ;;
        esac
        [[ "$choice" == "0" ]] || pause_screen
    done
}

case "${1:-}" in
  --help|-h) show_help ;;
  --backup) create_backup ;;
  --cron) run_cron_task ;;
  "") run_menu ;;
  *) echo "Unknown option: $1"; show_help; exit 1 ;;
esac
