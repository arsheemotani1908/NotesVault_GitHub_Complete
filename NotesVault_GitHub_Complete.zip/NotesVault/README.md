# Notes Vault – Linux Notes Management System

A menu-driven Linux notes manager developed using Bash scripting.

## Features
1. Create notes with title, tags and multi-line content.
2. Search notes by keyword or tag.
3. View the five most recently modified notes.
4. Count notes by tag.
5. Create compressed `.tar.gz` backups.
6. View all saved notes.
7. View recent activity logs.
8. Run scheduled backup tasks using cron.

## Requirements
- Linux / Ubuntu
- Bash
- Standard utilities: `find`, `grep`, `sed`, `sort`, `tar`, `date`

## Project structure
```text
NotesVault/
├── main.sh
├── README.md
├── .gitignore
├── lib/functions.sh
├── data/notes/
├── backups/
├── logs/
└── reports/
```

## Run the project
```bash
chmod +x main.sh
./main.sh
```

Other commands:
```bash
./main.sh --help
./main.sh --backup
./main.sh --cron
```

## Create a note
Choose option 1, enter a title and tags, then type the note content. Type `END` on a separate line to finish. Notes are saved in `data/notes/`.

## Cron scheduling
Find the absolute project path using `pwd`, then run `crontab -e`.
Example weekly Sunday midnight schedule (replace the path with your actual path):
```cron
0 0 * * 0 /bin/bash /home/USERNAME/linux_project/notesvault/main.sh --cron
```
Check the schedule using `crontab -l`. Cron output is appended to `reports/cron_output.txt`.

## GitHub
Do not commit private information or generated backup archives. The `.gitignore` file excludes generated logs, reports and backups.
