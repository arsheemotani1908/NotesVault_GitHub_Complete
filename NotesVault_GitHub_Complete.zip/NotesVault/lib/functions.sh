#!/bin/bash
log_activity() {
    mkdir -p "$(dirname "$LOG")"
    printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG"
}
pause_screen() {
    echo
    read -r -p "Press Enter to continue..." _
}
show_help() {
    cat <<'HELP'
Notes Vault - Linux Notes Management System
Usage:
  ./main.sh          Open the interactive menu
  ./main.sh --help   Display help
  ./main.sh --backup Create a compressed backup
  ./main.sh --cron   Run the scheduled backup task
HELP
}
create_backup() {
    local archive
    mkdir -p "$BACKUP_DIR"
    if ! find "$NOTES_DIR" -maxdepth 1 -type f -name '*.txt' -print -quit | grep -q .; then
        echo "No notes found. Backup not created."
        log_activity "Backup skipped: no notes found"
        return 1
    fi
    archive="$BACKUP_DIR/notes_$(date '+%Y%m%d_%H%M%S').tar.gz"
    if tar -czf "$archive" -C "$PROJECT_DIR" data/notes; then
        echo "Backup created: ${archive#"$PROJECT_DIR"/}"
        du -h "$archive"
        log_activity "Created backup: $(basename "$archive")"
    else
        echo "Backup failed."
        log_activity "Backup failed"
        return 1
    fi
}
run_cron_task() {
    local report="$REPORT_DIR/cron_output.txt"
    mkdir -p "$REPORT_DIR"
    {
        echo "Cron task started: $(date '+%Y-%m-%d %H:%M:%S')"
        if create_backup; then
            echo "Cron task status: SUCCESS"
            log_activity "Cron backup completed successfully"
        else
            echo "Cron task status: FAILED"
            log_activity "Cron backup failed"
        fi
        echo "Cron task finished: $(date '+%Y-%m-%d %H:%M:%S')"
        echo "----------------------------------------"
    } >> "$report" 2>&1
    echo "Cron output saved in reports/cron_output.txt"
}
